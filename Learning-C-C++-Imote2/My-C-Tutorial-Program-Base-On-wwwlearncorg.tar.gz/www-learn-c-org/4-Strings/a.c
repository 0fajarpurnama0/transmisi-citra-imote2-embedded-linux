#include<stdio.h>

int main() {
 char * name = "John Smith";
 int age = 27;
 
 /* prints out 'John Smith is 27 years old.' */
 printf("%s is %d years old. \n", name, age);
return 0;
}
