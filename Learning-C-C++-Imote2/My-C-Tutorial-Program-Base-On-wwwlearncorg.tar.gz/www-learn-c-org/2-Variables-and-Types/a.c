#include <stdio.h>

int main() {
 int a = 0, b = 1, c = 2, d = 3, e = 4;
 a = b - c + d * e;
 printf("a = b - c + d * e = %d \n", a);
 printf("b = %d \n", b);
 printf("c = %d \n", c);
 printf("d = %d \n", d);
 printf("e = %d \n", e);
 return 0;
}
