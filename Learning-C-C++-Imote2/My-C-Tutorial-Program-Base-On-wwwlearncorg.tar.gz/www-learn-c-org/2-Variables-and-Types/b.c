#include <stdio.h>

int main() {
 int a = 3;
 float b = 4.5;
 double c = 5.25;
 float sum = a + b + c;
 printf("The sum of %d, %f, and %f is %f.\n",a, b, c, sum);
 return 0;
}
