#include <stdio.h>

int main() {
 printf("Goodbye, Wordl!");
 return 0;
}
