#include<stdio.h>

void moo() {
 printf("moo function");
 /* don't return */
}

int main() {
 moo();
return 0;
}
