#include<stdio.h>

int foo(int bar) {
 /* do something */
 return bar * 2;
}

int main() {
 printf("%d", foo(1));
return 0;
}
